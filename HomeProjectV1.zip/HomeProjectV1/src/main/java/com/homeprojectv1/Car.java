package com.homeprojectv1;

public class Car {
    String make = "BMV";
    String model = "i5";
    int year = 2020;
    String color = "blue";
    double price = 89000.00;

    void drive(){
        System.out.println("You are the driving the "+make);
    }

    void brake(){
        System.out.println("You step on the brakes");
    }
}
