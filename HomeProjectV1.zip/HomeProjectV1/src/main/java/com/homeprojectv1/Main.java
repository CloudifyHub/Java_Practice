package com.homeprojectv1;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import javax.swing.undo.AbstractUndoableEdit;
import java.io.IOException;
import java.net.PortUnreachableException;
import java.sql.PseudoColumnUsage;
import java.sql.SQLOutput;
import java.time.LocalDate;
import java.util.Scanner;
import javax.swing.JOptionPane;
import java.util.Random;
import java.util.ArrayList;
import java.util.*;
import java.util.Date;
import java.util.Locale;





public class Main {
    public static void main(String[] args) {
        //System.out.println("Hello world!");
        //int number = 100;
        //String brand = "Richmond";
        // Date date = new Date();
        //System.out.println(date);
        //System.out.println(number);
        //LocalDate now = LocalDate.now();



        // System.out.println(name.toLowerCase());
        // System.out.println(now.getMonth());

        //String name = new String("RICHMOND ASAMOAH");
        // System.out.println(name.charAt(2));
        // System.out.println(name.contains("ASAMOAH"));



        //sendMsg("233546640723", "first sms from java app date", "Cloudify");
        //sendMsg();
        //useOperator();
        //useOperator();
        //ifStatement();
        //learnScanner();
        //expressions();
        //gui();
        //randomValues();
        //switches();
        //whileLoops();
        //forLoops();
        //arrays();
        //arraysAd();
        //twoDArrays();
        //usefulMethods();
        //wrapperClass();
        //arrayList();
        //arrayList2d();
        //forEachLoop();

        //overload method
        //int x = add(1,3);
        //int x = add(2,3,2,2);
        //double x = add(2.3,4.2);
       //System.out.println(x);
        //finalDeclare();

        //OPP
        Car myCars = new Car();
        Car myCars1 = new Car();

        System.out.println(myCars.make);
        System.out.println(myCars1.price);
        myCars.drive();

    }

    public static void useOperator(){
        int richmondAge = 19;
        int asamoahAge = 20;
        boolean isRichmondOldThanAsamoah = richmondAge > asamoahAge;
        System.out.println(richmondAge == asamoahAge);
    }

    public static void isLogical(){
        boolean isAdult = false;
        boolean isStudent = true;
        System.out.println(!isAdult && isStudent);

    }

    public static void ifStatement(){
        // && and || or == equal  ! not equal b
        int age = 17;
        if (age > 19){
            System.out.println(age);
        } else if (age >= 16 || age < 19){
            System.out.println("Greater equal age");
        } else {
            System.out.println("Greater than age");
        }

    }


    public static void sendMsg()
    {
        LocalDate smsDate = LocalDate.now();
        String toTelephone = "233546640723";
        String msg = "Am super excited to send sms from Java adding util date to message. "+smsDate+"";
        String senderName = "Cloudify";

        OkHttpClient client = new OkHttpClient().newBuilder() .build();
        Request request = new Request.Builder()
                .get()
                .url("https://sms.arkesel.com/sms/api?action=send-sms&" +
                        "api_key=OkVyVmRab3pzNjlZbmJsbHE!=&" +
                        "to=" +toTelephone+
                        "&" +
                        "from="+senderName+"&" +
                        "sms="+msg.toUpperCase())
                .build();
        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);
            System.out.println(response.body().string());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    public static void learnScanner (){
        Scanner scanner = new Scanner(System.in);
        System.out.println("What is your name? ");
        String name = scanner.nextLine();
        System.out.println("How old are you now?");
        int age = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Whats your fav food?");
        String food = scanner.nextLine();

        System.out.println("Welcome " +name.toUpperCase()+ ", is great to have you. Hurry!! you are "+age+" years old now. You also like "+food.toUpperCase()+"...Hmmmm i see");
        scanner.close();
    }



    public static void expressions(){
        //expresions = operands + operators
        int friends = 10;
        friends++;
        System.out.println(friends);
    }


    public static void gui(){
        String name = JOptionPane.showInputDialog("Enter your name");
        int age = Integer.parseInt(JOptionPane.showInputDialog("Enter your age"));
        double height = Double.parseDouble(JOptionPane.showInputDialog("Enter your height"));

        JOptionPane.showMessageDialog(null, "Weclome "+name);
        JOptionPane.showMessageDialog(null, "You are" +age+ "years old");
        JOptionPane.showMessageDialog(null, "You are" +height+ "cm tall");


    }


    public static void randomValues() {
        Random random = new Random();
        int x = random.nextInt();
        double y = random.nextDouble();
        System.out.println(y);

    }

    public static void switches(){
        String day = "Friday";
        switch (day){
            case "Sunday": System.out.println("Its sunday");
            break;
            case "Monday": System.out.println("Its Monday");
            break;
            case "Tuesday": System.out.println("Its Tuesday");
            break;
            case "Wednesday": System.out.println("Its Wed");
            break;
            case "Thursday": System.out.println("Its Thursday");
            break;
            case "Friday": System.out.println("Its Friday");
            //sendMsg();
            break;
            case "Saturday": System.out.println("Its Sat");
            break;
            default:System.out.println("Invalid Day");
        }
    }


    public static void whileLoops(){
        Scanner scanner = new Scanner(System.in);
        String name = "";

        while(name.isBlank()){
            System.out.println("Enter the name");
            name = scanner.nextLine();
        }
        System.out.println("Hello" +name);

    }

    public static void forLoops(){
        for(int i = 0; i<=10000; i++){
            System.out.println(i);
            //sendMsg();
        }
    }

    public static void arrays(){
        String[] cars = {"B.M.W", "BENZ", "TOYATO CAMRY"};
        cars[0] = "FORD";
        for(int i =0; i <=2; i++){
            System.out.println("I will one day drive " +cars[i]);
        }
        //System.out.println(cars[2]);
    }

    public static void arraysAd(){
        String[] car = new String[3];
        car[0] = "BMW";
        car[1] = "BENZ";
        car[2] = "AUDI";

        for(int i=0; i<car.length; i++){
            System.out.println(car[i]);
        }
    }

    public static void twoDArrays(){
        //2D ARRAYS
        String[][] cars = new String[3][3];
        cars[0][0] = "BMW";

    }


    public static void usefulMethods(){
        String name = "Richmond";
        //boolean result = name.equals("Richmond");
        //boolean result = name.equalsIgnoreCase("richmond");
        //int result = name.length();
        //char result = name.charAt(2);
        //boolean result = name.isEmpty();
        //String result = name.toLowerCase();
        //result = name.trim();
        String result = name.replace('i','a');
        System.out.println(result);
    }

    public static void wrapperClass(){
        Boolean a = true;
        Character b = '@';
        Integer c = 123;
        Double d = 3.12;
        String e = "Richmond";

        if(a==true){
            System.out.println("this is true");
        }
        if(b=='@'){
            System.out.println("this is @");
        }
    }

        public static void arrayList(){
            ArrayList<String > food = new ArrayList<String>();
            food.add("Jollof");
            food.add("Banku and Okro Soup");
            food.add("FuFu and Aponkye Krakra");

            food.set(0,"Omo Tuo and Groundsoup"); //replace a value in an array
            //food.remove(1);  //remove a value in and array
            //food.clear();  //clear values in an array

            for(int i=0; i<food.size(); i++){
                System.out.println(food.get(i));
            }
        }


        public static void arrayList2d(){
        //2d dimensional array
            ArrayList<ArrayList<String>> groceryList = new ArrayList();

            ArrayList<String> bakeryList = new ArrayList();
            bakeryList.add("Pizza");
            bakeryList.add("Garlic");
            bakeryList.add("Donut");

            ArrayList<String> produceList = new ArrayList();
            produceList.add("tomatoes");
            produceList.add("orange");
            produceList.add("ginger");

            ArrayList<String> drinkList = new ArrayList();
            drinkList.add("tomatoes");
            drinkList.add("orange");
            drinkList.add("ginger");

            groceryList.add(bakeryList);
            groceryList.add(produceList);
            groceryList.add(drinkList);

            System.out.println(drinkList);
            System.out.println(groceryList.get(2).get(1));
        }

      public static void forEachLoop(){
        //for -each loop for array and collection  : each
        ArrayList<String> animals = new ArrayList<String>();

        //String[] animals = {"RICHMOND","DARLINGTON","ASAMOAH","NIGGA"};
        animals.add("RICHMOND");
        animals.add("TEYE");
        animals.add("MENSAH");
        animals.add("ASAMOAH");

        for(String i : animals){
            System.out.println(i);
        }
      }


      //overloaded methods
      static int add(int a, int b){
          System.out.println("This is overloaded method #1");
          return a + b;
    }

    static int add(int a, int b, int c){
        System.out.println("This is overloaded method #2");
        return a + b + c;
    }

    static int add(int a, int b, int c, int d){
        System.out.println("This is overloaded method #3");
        return a + b + c + d;
    }

    static double add(double a, double b){
        System.out.println("This is overloaded method #1");
        return a + b;
    }


    public static void finalDeclare(){

        double pi = 2.3432;
        pi = 3.22;
        //final cannot be changed

        final double PI = 34.24;
        System.out.println(PI);
    }


}


